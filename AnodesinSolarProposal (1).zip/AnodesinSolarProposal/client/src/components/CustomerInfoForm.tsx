import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const customerInfoSchema = z.object({
  customerName: z.string().min(1, "Customer name is required"),
  customerAddress: z.string().min(1, "Address is required"),
  customerContact: z.string().min(10, "Valid contact number required"),
  consumerNumber: z.string().min(1, "Consumer number is required"),
  monthlyUnits: z.coerce.number().min(1, "Monthly units must be greater than 0"),
  currentBillAmount: z.coerce.number().min(0, "Bill amount must be positive"),
  demandCharges: z.coerce.number().min(0, "Demand charges must be positive"),
  sanctionLoad: z.coerce.number().min(0, "Sanction load must be positive"),
  proposedSystemKw: z.coerce.number().min(0, "System capacity must be positive"),
  rooftopArea: z.coerce.number().min(0, "Rooftop area must be positive"),
  projectCostPerKw: z.coerce.number().min(0, "Cost per kW must be positive"),
  ppaRate: z.coerce.number().optional(),
  subsidyAmount: z.coerce.number().optional(),
});

export type CustomerInfo = z.infer<typeof customerInfoSchema>;

interface CustomerInfoFormProps {
  onSubmit: (data: CustomerInfo) => void;
  defaultValues?: Partial<CustomerInfo>;
}

export default function CustomerInfoForm({ onSubmit, defaultValues }: CustomerInfoFormProps) {
  const form = useForm<CustomerInfo>({
    resolver: zodResolver(customerInfoSchema),
    defaultValues: defaultValues || {
      customerName: "",
      customerAddress: "",
      customerContact: "",
      consumerNumber: "",
      monthlyUnits: 0,
      currentBillAmount: 0,
      demandCharges: 0,
      sanctionLoad: 0,
      proposedSystemKw: 0,
      rooftopArea: 0,
      projectCostPerKw: 55000,
      ppaRate: 0,
      subsidyAmount: 0,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="customerName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Customer Name <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Input placeholder="Enter customer name" {...field} data-testid="input-customer-name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="consumerNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Consumer Number <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Input placeholder="Enter consumer number" {...field} data-testid="input-consumer-number" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="customerContact"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Contact Number <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Input placeholder="Enter phone number" {...field} data-testid="input-customer-contact" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="customerAddress"
            render={({ field }) => (
              <FormItem className="md:col-span-2">
                <FormLabel>Address <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Textarea placeholder="Enter complete address" {...field} data-testid="input-customer-address" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="monthlyUnits"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Monthly Electricity Units (kWh) <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Input type="number" placeholder="e.g., 1200" {...field} data-testid="input-monthly-units" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="currentBillAmount"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Current Bill Amount (₹) <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Input type="number" placeholder="e.g., 12000" {...field} data-testid="input-bill-amount" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="demandCharges"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Demand/Fixed Charges (₹) <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Input type="number" placeholder="e.g., 639" {...field} data-testid="input-demand-charges" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="sanctionLoad"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Sanction Load (kW) <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Input type="number" placeholder="e.g., 15" {...field} data-testid="input-sanction-load" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="proposedSystemKw"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Proposed Solar System (kW) <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Input type="number" placeholder="e.g., 55" {...field} data-testid="input-proposed-system" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="rooftopArea"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Rooftop Area (Sq. Ft.) <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Input type="number" placeholder="e.g., 2500" {...field} data-testid="input-rooftop-area" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="projectCostPerKw"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Project Cost per kW (₹) <span className="text-destructive">*</span></FormLabel>
                <FormControl>
                  <Input type="number" placeholder="e.g., 55000" {...field} data-testid="input-cost-per-kw" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="ppaRate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>PPA Rate (₹/unit) (Optional)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="e.g., 10" {...field} data-testid="input-ppa-rate" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="subsidyAmount"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Government Subsidy (₹) (Optional)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="e.g., 30000" {...field} data-testid="input-subsidy-amount" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex justify-end">
          <Button type="submit" size="lg" data-testid="button-submit-customer-info">
            Continue to Assessment
          </Button>
        </div>
      </form>
    </Form>
  );
}
