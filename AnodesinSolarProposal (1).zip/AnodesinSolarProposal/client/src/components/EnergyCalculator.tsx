import { Card } from "@/components/ui/card";
import { Calculator, Sun, Zap, TrendingUp, Lightbulb, Battery } from "lucide-react";

interface EnergyCalculatorProps {
  monthlyUnits: number;
  proposedSystemKw: number;
}

export default function EnergyCalculator({ monthlyUnits, proposedSystemKw }: EnergyCalculatorProps) {
  // Calculations
  const dailyUnits = monthlyUnits / 30;
  const unitsPerKw = 4; // 4 units per day per kW
  const requiredSystemKw = Math.ceil(monthlyUnits / 120); // Monthly units / 120
  const dailyGeneration = proposedSystemKw * unitsPerKw;
  const monthlyGeneration = dailyGeneration * 30;
  const annualGeneration = monthlyGeneration * 12;
  const savingsPercentage = Math.min(Math.round((monthlyGeneration / monthlyUnits) * 100), 100);

  return (
    <div className="space-y-8">
      {/* Solar-themed Header */}
      <div className="relative overflow-hidden rounded-lg bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 p-8 text-white">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
        <div className="relative z-10">
          <Sun className="w-12 h-12 mb-3" />
          <h2 className="text-3xl font-semibold mb-2" data-testid="text-calculator-title">
            Energy Assessment & System Sizing
          </h2>
          <p className="text-yellow-100">
            Based on your electricity consumption pattern and available rooftop area
          </p>
        </div>
      </div>

      {/* Calculation Cards with Solar Theme */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="p-6 space-y-3 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950 border-blue-200 dark:border-blue-800">
          <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center">
            <Lightbulb className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="text-sm text-blue-800 dark:text-blue-200">Monthly Consumption</p>
            <p className="text-3xl font-bold font-mono text-blue-600 dark:text-blue-400" data-testid="text-monthly-consumption">
              {monthlyUnits}
            </p>
            <p className="text-xs text-blue-700 dark:text-blue-300">units/month</p>
          </div>
        </Card>

        <Card className="p-6 space-y-3 bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-950 dark:to-amber-950 border-orange-200 dark:border-orange-800">
          <div className="w-12 h-12 rounded-full bg-orange-500 flex items-center justify-center">
            <Sun className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="text-sm text-orange-800 dark:text-orange-200">Recommended System</p>
            <p className="text-3xl font-bold font-mono text-orange-600 dark:text-orange-400" data-testid="text-recommended-system">
              {requiredSystemKw}
            </p>
            <p className="text-xs text-orange-700 dark:text-orange-300">kW capacity</p>
          </div>
        </Card>

        <Card className="p-6 space-y-3 bg-gradient-to-br from-yellow-50 to-lime-50 dark:from-yellow-950 dark:to-lime-950 border-yellow-200 dark:border-yellow-800">
          <div className="w-12 h-12 rounded-full bg-yellow-500 flex items-center justify-center">
            <Battery className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="text-sm text-yellow-800 dark:text-yellow-200">Proposed System</p>
            <p className="text-3xl font-bold font-mono text-yellow-600 dark:text-yellow-400" data-testid="text-proposed-system">
              {proposedSystemKw}
            </p>
            <p className="text-xs text-yellow-700 dark:text-yellow-300">kW DC capacity</p>
          </div>
        </Card>

        <Card className="p-6 space-y-3 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-green-200 dark:border-green-800">
          <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="text-sm text-green-800 dark:text-green-200">Estimated Savings</p>
            <p className="text-3xl font-bold font-mono text-green-600 dark:text-green-400" data-testid="text-savings-percentage">
              {savingsPercentage}%
            </p>
            <p className="text-xs text-green-700 dark:text-green-300">of monthly bill</p>
          </div>
        </Card>
      </div>

      {/* Generation Details */}
      <Card className="p-8">
        <h3 className="text-lg font-semibold mb-6">Expected Generation</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <p className="text-sm text-muted-foreground mb-2">Daily Generation</p>
            <p className="text-2xl font-bold font-mono" data-testid="text-daily-generation">
              {dailyGeneration} <span className="text-base font-normal text-muted-foreground">units</span>
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {proposedSystemKw} kW × 4 units/day
            </p>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-2">Monthly Generation</p>
            <p className="text-2xl font-bold font-mono" data-testid="text-monthly-generation">
              {monthlyGeneration} <span className="text-base font-normal text-muted-foreground">units</span>
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {dailyGeneration} units × 30 days
            </p>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-2">Annual Generation</p>
            <p className="text-2xl font-bold font-mono" data-testid="text-annual-generation">
              {annualGeneration.toLocaleString('en-IN')} <span className="text-base font-normal text-muted-foreground">units</span>
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {monthlyGeneration} units × 12 months
            </p>
          </div>
        </div>
      </Card>

      {/* Net Metering Benefit */}
      <Card className="p-6 bg-primary/5 border-primary/20">
        <h3 className="text-lg font-semibold mb-3">Net Metering Benefits</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          With on-grid net metering system, excess electricity generated during the day will be fed to the grid.
          At the end of each month, MSEB will adjust the units you consumed against the units you generated,
          resulting in minimal to zero electricity bills. This system operates with zero maintenance costs.
        </p>
      </Card>
    </div>
  );
}
