import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

// Import images
import img1 from "@assets/IMG20250421141750_1761342095685.jpg";
import img2 from "@assets/IMG_20231119_180644_1761342095686.jpg";
import img3 from "@assets/IMG-20240417-WA0012_1761342095687.jpg";
import img4 from "@assets/IMG-20240425-WA0028_1761342095688.jpg";
import img5 from "@assets/IMG-20240426-WA0047_1761342095688.jpg";
import img6 from "@assets/IMG-20240715-WA0011_1761342095689.jpg";
import img7 from "@assets/IMG-20250115-WA0005_1761342095690.jpg";
import img8 from "@assets/IMG-20250128-WA0002 (1)_1761342095690.jpg";
import img9 from "@assets/IMG-20250214-WA0021_1761342095691.jpg";
import img10 from "@assets/IMG-20250214-WA0028_1761342095692.jpg";

const installations = [
  { id: 1, image: img1, title: "Residential Installation - Indoor Panel Setup", location: "Pune" },
  { id: 2, image: img2, title: "Large Scale Ground Mount Installation", location: "Maharashtra" },
  { id: 3, image: img3, title: "Rooftop Solar with Water Heaters", location: "Pune" },
  { id: 4, image: img4, title: "Commercial Rooftop Installation", location: "Maharashtra" },
  { id: 5, image: img5, title: "Residential Rooftop Array", location: "Pune" },
  { id: 6, image: img6, title: "Technician Installing Panels", location: "Pune" },
  { id: 7, image: img7, title: "Residential Ground Installation", location: "Maharashtra" },
  { id: 8, image: img8, title: "Industrial Rooftop Installation", location: "Maharashtra" },
  { id: 9, image: img9, title: "Industrial Ground Mount Project", location: "Maharashtra" },
  { id: 10, image: img10, title: "Large Commercial Installation", location: "Maharashtra" },
];

export default function InstallationGallery() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  return (
    <div className="space-y-8">
      {/* Solar-themed Header */}
      <div className="relative overflow-hidden rounded-lg bg-gradient-to-r from-amber-600 via-yellow-500 to-orange-500 p-8 text-white">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
        <div className="relative z-10 flex items-center gap-4">
          <div className="text-6xl">📸</div>
          <div>
            <h2 className="text-3xl font-semibold mb-2" data-testid="text-gallery-title">
              Installation Gallery
            </h2>
            <p className="text-yellow-100">
              Browse through our completed solar installations across Maharashtra
            </p>
          </div>
        </div>
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {installations.map((installation) => (
          <Card 
            key={installation.id}
            className="overflow-hidden cursor-pointer hover-elevate active-elevate-2 transition-all"
            onClick={() => setSelectedImage(installation.id)}
            data-testid={`card-installation-${installation.id}`}
          >
            <div className="aspect-video relative overflow-hidden">
              <img 
                src={installation.image}
                alt={installation.title}
                className="w-full h-full object-cover transition-transform hover:scale-105"
                loading="lazy"
              />
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-sm mb-1">{installation.title}</h3>
              <p className="text-xs text-muted-foreground">{installation.location}</p>
            </div>
          </Card>
        ))}
      </div>

      {/* Lightbox Modal */}
      <Dialog open={selectedImage !== null} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-5xl p-0">
          {selectedImage && (
            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-4 right-4 z-10 bg-background/80 hover:bg-background"
                onClick={() => setSelectedImage(null)}
                data-testid="button-close-lightbox"
              >
                <X className="w-4 h-4" />
              </Button>
              <img 
                src={installations[selectedImage - 1].image}
                alt={installations[selectedImage - 1].title}
                className="w-full h-auto"
              />
              <div className="p-6 bg-background">
                <h3 className="font-semibold text-lg">{installations[selectedImage - 1].title}</h3>
                <p className="text-sm text-muted-foreground">{installations[selectedImage - 1].location}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
