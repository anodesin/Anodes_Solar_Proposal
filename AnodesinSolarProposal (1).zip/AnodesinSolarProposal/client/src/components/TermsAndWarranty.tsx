import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Shield } from "lucide-react";

export default function TermsAndWarranty() {
  return (
    <div className="space-y-8">
      {/* Solar-themed Header */}
      <div className="relative overflow-hidden rounded-lg bg-gradient-to-r from-slate-700 via-gray-600 to-zinc-600 p-8 text-white">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
        <div className="relative z-10">
          <Shield className="w-12 h-12 mb-3" />
          <h2 className="text-3xl font-semibold mb-2" data-testid="text-terms-title">
            Terms, Conditions & Warranty Details
          </h2>
          <p className="text-gray-100">
            Complete project terms and comprehensive warranty information
          </p>
        </div>
      </div>

      <Tabs defaultValue="terms" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="terms" className="gap-2" data-testid="tab-terms">
            <FileText className="w-4 h-4" />
            Terms & Conditions
          </TabsTrigger>
          <TabsTrigger value="warranty" className="gap-2" data-testid="tab-warranty">
            <Shield className="w-4 h-4" />
            Warranty Details
          </TabsTrigger>
        </TabsList>

        <TabsContent value="terms" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Payment Terms</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <div className="flex gap-3">
                <span className="font-semibold text-foreground min-w-32">Advance Payment:</span>
                <span>30% of total project cost at the time of order confirmation</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold text-foreground min-w-32">Second Payment:</span>
                <span>40% upon delivery of materials at site</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold text-foreground min-w-32">Final Payment:</span>
                <span>30% upon successful commissioning and handover</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold text-foreground min-w-32">GST:</span>
                <span>8.9% GST applicable on all payments</span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Project Timeline</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <p>• Total project duration: 2 months from the date of advance payment</p>
              <p>• Timeline subject to timely approvals and site readiness</p>
              <p>• Net meter installation timeline depends on electricity board processing</p>
              <p>• Force majeure events may extend timeline without penalty</p>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Scope Inclusions</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <p>• Design, supply, installation, and commissioning of complete solar system</p>
              <p>• All materials and components as per Bill of Materials</p>
              <p>• Civil work for mounting structure foundations</p>
              <p>• Electrical wiring and connections up to main distribution board</p>
              <p>• Net meter installation coordination with electricity board</p>
              <p>• System testing, commissioning, and customer training</p>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Scope Exclusions</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <p>• Main distribution board upgrades (if required)</p>
              <p>• Structural strengthening of existing rooftop (if needed)</p>
              <p>• Government subsidy application and processing fees</p>
              <p>• Electricity board charges for net meter and inspection</p>
              <p>• Periodic cleaning and maintenance of solar panels</p>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">General Terms</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <p>• This proposal is valid for 30 days from the date of issue</p>
              <p>• Prices are subject to change based on component availability</p>
              <p>• Customer shall provide safe and secure site access</p>
              <p>• Any damage to existing structures during installation will be repaired at actual cost</p>
              <p>• Disputes, if any, shall be subject to Pune jurisdiction</p>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="warranty" className="space-y-6">
          <Card className="p-6 bg-primary/5 border-primary/20">
            <h3 className="text-lg font-semibold mb-4">Comprehensive Warranty Coverage</h3>
            <p className="text-sm text-muted-foreground">
              All components come with manufacturer warranties. Anodes Incorporate provides 
              installation workmanship warranty and facilitates warranty claims with manufacturers.
            </p>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Solar Panels - 27 Years</h3>
            <div className="space-y-3 text-sm">
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Product Warranty:</span>
                <span className="text-muted-foreground">10 years against manufacturing defects</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Performance Warranty:</span>
                <span className="text-muted-foreground">27 years linear power output guarantee</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Year 1:</span>
                <span className="text-muted-foreground">Minimum 97% of rated power output</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Year 25:</span>
                <span className="text-muted-foreground">Minimum 84% of rated power output</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Coverage:</span>
                <span className="text-muted-foreground">Replacement or repair of defective panels</span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Inverter - 5 Years</h3>
            <div className="space-y-3 text-sm">
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Warranty Period:</span>
                <span className="text-muted-foreground">5 years comprehensive warranty</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Coverage:</span>
                <span className="text-muted-foreground">Repair or replacement of defective units</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Extended Warranty:</span>
                <span className="text-muted-foreground">Available at additional cost</span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Mounting Structure - 15 Years</h3>
            <div className="space-y-3 text-sm">
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Warranty Period:</span>
                <span className="text-muted-foreground">15 years against corrosion and structural failure</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Material:</span>
                <span className="text-muted-foreground">Hot-dipped galvanized steel</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Coverage:</span>
                <span className="text-muted-foreground">Replacement of corroded or failed components</span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Other Components - 5 Years</h3>
            <div className="space-y-3 text-sm">
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">ACDB/DCDB:</span>
                <span className="text-muted-foreground">5 years manufacturer warranty</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Cables:</span>
                <span className="text-muted-foreground">5 years Polycab warranty</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Earthing Kit:</span>
                <span className="text-muted-foreground">5 years warranty</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Net Meter:</span>
                <span className="text-muted-foreground">1 year manufacturer warranty</span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Installation Workmanship - 2 Years</h3>
            <div className="space-y-3 text-sm">
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Warranty Period:</span>
                <span className="text-muted-foreground">2 years from commissioning date</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Coverage:</span>
                <span className="text-muted-foreground">Free rectification of installation defects</span>
              </div>
              <div className="flex gap-3">
                <span className="font-semibold min-w-40">Exclusions:</span>
                <span className="text-muted-foreground">Physical damage, natural disasters, tampering</span>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-muted/50">
            <h3 className="text-sm font-semibold mb-3">Warranty Claim Process</h3>
            <ol className="space-y-2 text-sm text-muted-foreground list-decimal list-inside">
              <li>Contact Anodes Incorporate with issue details and photos</li>
              <li>Our technical team will assess the problem remotely or on-site</li>
              <li>If covered under warranty, repair/replacement at no cost</li>
              <li>Typical resolution time: 7-15 working days</li>
              <li>Extended warranty available for purchase on all components</li>
            </ol>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
