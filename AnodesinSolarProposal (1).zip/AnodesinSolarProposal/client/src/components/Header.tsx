import logoUrl from "@assets/Baner_3X1P5_12 Low_1761342080049.jpg";
import { Phone, Mail, Globe, MapPin } from "lucide-react";

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex-shrink-0">
            <img 
              src={logoUrl} 
              alt="Anodes Incorporate" 
              className="h-12 w-auto object-contain"
              data-testid="img-company-logo"
            />
          </div>

          {/* Company Details */}
          <div className="hidden md:flex flex-col items-end gap-1 text-sm">
            <div className="flex items-center gap-4 text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" />
                <span data-testid="text-company-address">Pimpri, Pune – 411017</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5" />
                <span data-testid="text-company-website">www.anodes.in</span>
              </div>
            </div>
            <div className="flex items-center gap-4 text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5" />
                <span data-testid="text-company-phone">7767000707</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5" />
                <span data-testid="text-company-email">info@anodes.in</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
