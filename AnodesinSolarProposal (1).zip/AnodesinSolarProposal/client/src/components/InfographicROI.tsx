import { Card } from "@/components/ui/card";
import { TrendingUp, Zap, IndianRupee, Target, Sun, Award, Leaf } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface InfographicROIProps {
  systemKw: number;
  totalInvestment: number;
  unitRate: number;
}

export default function InfographicROI({ systemKw, totalInvestment, unitRate }: InfographicROIProps) {
  // Calculations
  const annualGeneration = systemKw * 4 * 365; // 4 units per day per kW
  const totalGeneration25Years = annualGeneration * 25;
  const tariffEscalation = 0.02; // 2% annual
  const degradation = 0.005; // 0.5% annual

  // Calculate 25-year savings
  let totalSavings = 0;
  for (let year = 1; year <= 25; year++) {
    const degradationFactor = Math.pow(1 - degradation, year - 1);
    const unitsGenerated = annualGeneration * degradationFactor;
    const escalatedRate = unitRate * Math.pow(1 + tariffEscalation, year - 1);
    totalSavings += unitsGenerated * escalatedRate;
  }

  const netProfit = totalSavings - totalInvestment;
  const roi = ((netProfit / totalInvestment) * 100);
  
  // Payback calculation
  let cumulativeSavings = 0;
  let paybackYear = 0;
  for (let year = 1; year <= 25; year++) {
    const degradationFactor = Math.pow(1 - degradation, year - 1);
    const unitsGenerated = annualGeneration * degradationFactor;
    const escalatedRate = unitRate * Math.pow(1 + tariffEscalation, year - 1);
    cumulativeSavings += unitsGenerated * escalatedRate;
    if (cumulativeSavings >= totalInvestment && paybackYear === 0) {
      paybackYear = year;
    }
  }

  // Environmental impact
  const co2Offset = (totalGeneration25Years * 0.82) / 1000; // 0.82 kg CO2 per kWh, convert to tons
  const treesEquivalent = Math.round(co2Offset * 16.5); // 1 tree absorbs ~60kg CO2/year for 25 years

  return (
    <div className="space-y-12">
      {/* Hero Section with Solar Theme */}
      <div className="relative overflow-hidden rounded-lg bg-gradient-to-br from-blue-600 via-blue-500 to-cyan-500 p-12 text-white">
        <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-400/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-orange-400/20 rounded-full blur-3xl" />
        <div className="relative z-10 text-center">
          <Sun className="w-20 h-20 mx-auto mb-6 animate-pulse" />
          <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="text-infographic-title">
            Your Solar Investment at a Glance
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Visual representation of your {systemKw}kW solar power system's financial and environmental impact
          </p>
        </div>
      </div>

      {/* Key Metrics - Large Visual Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Investment */}
        <Card className="p-8 text-center bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950 dark:to-orange-950 border-2 border-orange-200 dark:border-orange-800">
          <div className="w-16 h-16 rounded-full bg-orange-500 flex items-center justify-center mx-auto mb-4">
            <IndianRupee className="w-8 h-8 text-white" />
          </div>
          <p className="text-sm font-semibold text-orange-800 dark:text-orange-200 mb-2">
            Total Investment
          </p>
          <p className="text-3xl font-bold font-mono text-orange-600 dark:text-orange-400" data-testid="text-total-investment">
            ₹{(totalInvestment / 100000).toFixed(2)}L
          </p>
          <p className="text-xs text-orange-700 dark:text-orange-300 mt-2">
            One-time solar setup cost
          </p>
        </Card>

        {/* Generation */}
        <Card className="p-8 text-center bg-gradient-to-br from-yellow-50 to-amber-50 dark:from-yellow-950 dark:to-amber-950 border-2 border-yellow-200 dark:border-yellow-800">
          <div className="w-16 h-16 rounded-full bg-yellow-500 flex items-center justify-center mx-auto mb-4">
            <Zap className="w-8 h-8 text-white" />
          </div>
          <p className="text-sm font-semibold text-yellow-800 dark:text-yellow-200 mb-2">
            25-Year Generation
          </p>
          <p className="text-3xl font-bold font-mono text-yellow-600 dark:text-yellow-400" data-testid="text-total-generation">
            {(totalGeneration25Years / 100000).toFixed(0)}L
          </p>
          <p className="text-xs text-yellow-700 dark:text-yellow-300 mt-2">
            units of clean energy
          </p>
        </Card>

        {/* Savings */}
        <Card className="p-8 text-center bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-2 border-green-200 dark:border-green-800">
          <div className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="w-8 h-8 text-white" />
          </div>
          <p className="text-sm font-semibold text-green-800 dark:text-green-200 mb-2">
            Total Savings
          </p>
          <p className="text-3xl font-bold font-mono text-green-600 dark:text-green-400" data-testid="text-total-savings-infographic">
            ₹{(totalSavings / 100000).toFixed(2)}L
          </p>
          <p className="text-xs text-green-700 dark:text-green-300 mt-2">
            over 25 years
          </p>
        </Card>

        {/* ROI */}
        <Card className="p-8 text-center bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-2 border-blue-200 dark:border-blue-800">
          <div className="w-16 h-16 rounded-full bg-blue-500 flex items-center justify-center mx-auto mb-4">
            <Target className="w-8 h-8 text-white" />
          </div>
          <p className="text-sm font-semibold text-blue-800 dark:text-blue-200 mb-2">
            Return on Investment
          </p>
          <p className="text-3xl font-bold font-mono text-blue-600 dark:text-blue-400" data-testid="text-roi-percentage">
            {roi.toFixed(0)}%
          </p>
          <p className="text-xs text-blue-700 dark:text-blue-300 mt-2">
            over 25 years
          </p>
        </Card>
      </div>

      {/* Visual ROI Timeline */}
      <Card className="p-8 bg-gradient-to-br from-primary/5 to-primary/10">
        <h2 className="text-2xl font-semibold mb-6 text-center">Investment Recovery Timeline</h2>
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-1">Start</p>
              <Badge variant="outline" className="text-lg px-4 py-2">Year 0</Badge>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-1">Breakeven</p>
              <Badge variant="default" className="text-lg px-4 py-2 bg-green-600">
                Year {paybackYear}
              </Badge>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-1">End</p>
              <Badge variant="outline" className="text-lg px-4 py-2">Year 25</Badge>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="relative h-8 bg-muted rounded-full overflow-hidden">
            <div 
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 transition-all"
              style={{ width: `${(paybackYear / 25) * 100}%` }}
            />
            <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center">
              <span className="text-xs font-semibold text-foreground">
                Investment Recovery in {paybackYear} years, then pure profit for {25 - paybackYear} years
              </span>
            </div>
          </div>
        </div>
      </Card>

      {/* Financial Breakdown - Visual */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Money Flow */}
        <Card className="p-8">
          <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
            <IndianRupee className="w-6 h-6 text-primary" />
            Financial Summary
          </h3>
          <div className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-950 rounded-lg">
              <div>
                <p className="text-sm text-muted-foreground">Investment</p>
                <p className="text-2xl font-bold text-red-600 dark:text-red-400">
                  -₹{(totalInvestment / 100000).toFixed(2)}L
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-red-500 flex items-center justify-center">
                <IndianRupee className="w-6 h-6 text-white" />
              </div>
            </div>

            <div className="flex items-center justify-center">
              <div className="text-center">
                <p className="text-4xl font-bold text-primary">+</p>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-950 rounded-lg">
              <div>
                <p className="text-sm text-muted-foreground">Total Savings</p>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                  +₹{(totalSavings / 100000).toFixed(2)}L
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>

            <div className="h-px bg-border" />

            <div className="flex items-center justify-between p-4 bg-blue-50 dark:bg-blue-950 rounded-lg border-2 border-blue-500">
              <div>
                <p className="text-sm text-muted-foreground">Net Profit</p>
                <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                  ₹{(netProfit / 100000).toFixed(2)}L
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center">
                <Award className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </Card>

        {/* Environmental Impact */}
        <Card className="p-8 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950">
          <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
            <Leaf className="w-6 h-6 text-green-600" />
            Environmental Impact
          </h3>
          <div className="space-y-6">
            <div className="text-center p-6 bg-white dark:bg-green-900 rounded-lg">
              <Leaf className="w-12 h-12 text-green-600 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground mb-2">CO₂ Emissions Offset</p>
              <p className="text-4xl font-bold text-green-600 dark:text-green-400 mb-1">
                {co2Offset.toFixed(0)}
              </p>
              <p className="text-sm text-muted-foreground">tons over 25 years</p>
            </div>

            <div className="text-center p-6 bg-white dark:bg-green-900 rounded-lg">
              <div className="text-5xl mb-3">🌳</div>
              <p className="text-sm text-muted-foreground mb-2">Equivalent to Planting</p>
              <p className="text-4xl font-bold text-green-600 dark:text-green-400 mb-1">
                {treesEquivalent}
              </p>
              <p className="text-sm text-muted-foreground">trees</p>
            </div>

            <div className="text-center p-4 bg-green-600 text-white rounded-lg">
              <p className="text-sm font-semibold">
                Contributing to a Sustainable Future
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Key Benefits Grid */}
      <div>
        <h2 className="text-2xl font-semibold mb-6 text-center">Why This is a Smart Investment</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 text-center hover-elevate">
            <div className="w-16 h-16 rounded-full bg-yellow-500 flex items-center justify-center mx-auto mb-4">
              <Sun className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold mb-2">Zero Fuel Cost</h3>
            <p className="text-sm text-muted-foreground">
              Sunlight is free and abundant. No recurring fuel expenses for 25+ years.
            </p>
          </Card>

          <Card className="p-6 text-center hover-elevate">
            <div className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold mb-2">Inflation Protection</h3>
            <p className="text-sm text-muted-foreground">
              Lock in energy costs while electricity tariffs rise 2-5% annually.
            </p>
          </Card>

          <Card className="p-6 text-center hover-elevate">
            <div className="w-16 h-16 rounded-full bg-blue-500 flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold mb-2">Property Value</h3>
            <p className="text-sm text-muted-foreground">
              Solar installations increase property value and appeal to buyers.
            </p>
          </Card>
        </div>
      </div>

      {/* Bottom CTA */}
      <Card className="p-8 bg-gradient-to-r from-primary to-blue-600 text-white text-center">
        <Sun className="w-16 h-16 mx-auto mb-4" />
        <h2 className="text-3xl font-bold mb-3">
          Start Saving from Day One
        </h2>
        <p className="text-lg text-blue-100 mb-6 max-w-2xl mx-auto">
          Every unit generated by your solar system translates to direct savings on your electricity bill. 
          The sooner you start, the more you save!
        </p>
        <div className="flex items-center justify-center gap-4 text-sm">
          <Badge variant="secondary" className="bg-white/20 text-white px-4 py-2">
            ✓ 25-Year Warranty
          </Badge>
          <Badge variant="secondary" className="bg-white/20 text-white px-4 py-2">
            ✓ Zero Maintenance
          </Badge>
          <Badge variant="secondary" className="bg-white/20 text-white px-4 py-2">
            ✓ Net Metering
          </Badge>
        </div>
      </Card>
    </div>
  );
}
