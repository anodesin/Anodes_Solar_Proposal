import { Card } from "@/components/ui/card";
import { IndianRupee, Percent, Calculator, TrendingDown, Banknote } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface PricingCalculatorProps {
  systemKw: number;
  costPerKw: number;
  subsidyAmount?: number;
}

export default function PricingCalculator({ systemKw, costPerKw, subsidyAmount = 0 }: PricingCalculatorProps) {
  const projectCost = systemKw * costPerKw;
  const gstRate = 0.089; // 8.9%
  const gstAmount = projectCost * gstRate;
  const totalPayableAmount = projectCost + gstAmount; // Total Payable = Basic + GST

  // Loan calculation based on Total Payable Amount (90% loan at 10% interest)
  const loanAmount = totalPayableAmount * 0.9;
  const downPayment = totalPayableAmount * 0.1;
  const interestRate = 0.10;
  const loanTerm = 5; // years
  const monthlyInterestRate = interestRate / 12;
  const numberOfPayments = loanTerm * 12;
  const monthlyEMI = loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfPayments) / 
                     (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold mb-2" data-testid="text-pricing-title">
          Pricing Structure & Investment
        </h2>
        <p className="text-muted-foreground">
          Complete cost breakdown for your {systemKw}kW solar installation
        </p>
      </div>

      {/* Main Pricing Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Calculator className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-muted-foreground mb-1">Base Project Cost</p>
              <p className="text-3xl font-bold font-mono" data-testid="text-project-cost">
                ₹{projectCost.toLocaleString('en-IN')}
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                {systemKw} kW × ₹{costPerKw.toLocaleString('en-IN')}/kW
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Percent className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-muted-foreground mb-1">GST (8.9%)</p>
              <p className="text-3xl font-bold font-mono" data-testid="text-gst-amount">
                ₹{gstAmount.toLocaleString('en-IN')}
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                Goods & Services Tax
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Total Payable Amount - Highlighted */}
      <Card className="p-8 border-2 border-primary bg-gradient-to-br from-primary/5 to-primary/10">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Banknote className="w-5 h-5 text-primary" />
              <p className="text-sm font-semibold text-primary">Total Payable Amount</p>
            </div>
            <p className="text-4xl font-bold font-mono text-primary" data-testid="text-total-payable">
              ₹{totalPayableAmount.toLocaleString('en-IN')}
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Base Cost (₹{projectCost.toLocaleString('en-IN')}) + GST (₹{gstAmount.toLocaleString('en-IN')})
            </p>
          </div>
          <IndianRupee className="w-16 h-16 text-primary/20" />
        </div>
      </Card>

      {/* Subsidy Information - Display Only */}
      {subsidyAmount > 0 && (
        <Card className="p-6 bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-green-600 flex items-center justify-center flex-shrink-0">
              <TrendingDown className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <p className="text-sm font-semibold text-green-800 dark:text-green-200">
                  Government Subsidy Available
                </p>
                <Badge variant="secondary" className="bg-green-200 dark:bg-green-900 text-green-800 dark:text-green-200">
                  For Reference
                </Badge>
              </div>
              <p className="text-3xl font-bold font-mono text-green-700 dark:text-green-300" data-testid="text-subsidy-amount">
                ₹{subsidyAmount.toLocaleString('en-IN')}
              </p>
              <p className="text-xs text-green-700 dark:text-green-400 mt-2">
                Note: Subsidy application and processing is separate. Actual subsidy amount may vary based on government guidelines.
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Financing Option - Calculated from Total Payable Amount */}
      <Card className="p-6 bg-muted/50 border-2 border-border">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Banknote className="w-5 h-5 text-primary" />
          Financing Option Available
        </h3>
        <p className="text-sm text-muted-foreground mb-6">
          Easy EMI plan calculated on Total Payable Amount of ₹{totalPayableAmount.toLocaleString('en-IN')}
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Down Payment (10%)</p>
            <p className="text-2xl font-bold font-mono" data-testid="text-down-payment">
              ₹{downPayment.toLocaleString('en-IN')}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Pay at project start
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Loan Amount (90%)</p>
            <p className="text-2xl font-bold font-mono" data-testid="text-loan-amount">
              ₹{loanAmount.toLocaleString('en-IN')}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              @ 10% interest for 5 years
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Monthly EMI</p>
            <p className="text-2xl font-bold font-mono text-primary" data-testid="text-monthly-emi">
              ₹{monthlyEMI.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              for 60 months
            </p>
          </div>
        </div>
      </Card>

      {/* Cost Breakdown Table */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Cost Breakdown Summary</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between py-2 border-b border-border">
            <span className="text-sm text-muted-foreground">System Capacity</span>
            <span className="font-semibold font-mono">{systemKw} kW</span>
          </div>
          <div className="flex items-center justify-between py-2 border-b border-border">
            <span className="text-sm text-muted-foreground">Rate per kW</span>
            <span className="font-semibold font-mono">₹{costPerKw.toLocaleString('en-IN')}</span>
          </div>
          <div className="flex items-center justify-between py-2 border-b border-border">
            <span className="text-sm text-muted-foreground">Base Project Cost</span>
            <span className="font-semibold font-mono">₹{projectCost.toLocaleString('en-IN')}</span>
          </div>
          <div className="flex items-center justify-between py-2 border-b border-border">
            <span className="text-sm text-muted-foreground">GST @ 8.9%</span>
            <span className="font-semibold font-mono">₹{gstAmount.toLocaleString('en-IN')}</span>
          </div>
          <div className="flex items-center justify-between py-3 bg-primary/5 px-3 rounded-md">
            <span className="text-base font-semibold">Total Payable Amount</span>
            <span className="text-xl font-bold font-mono text-primary">₹{totalPayableAmount.toLocaleString('en-IN')}</span>
          </div>
        </div>
      </Card>
    </div>
  );
}
