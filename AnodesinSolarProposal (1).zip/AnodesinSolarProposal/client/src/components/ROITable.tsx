import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { TrendingUp } from "lucide-react";

interface ROITableProps {
  systemKw: number;
  initialInvestment: number;
  unitRate: number;
}

export default function ROITable({ systemKw, initialInvestment, unitRate }: ROITableProps) {
  const annualGeneration = systemKw * 4 * 365; // 4 units per day per kW
  const tariffEscalation = 0.02; // 2% annual increase
  const degradation = 0.005; // 0.5% annual degradation

  const calculateYearData = (year: number) => {
    const degradationFactor = Math.pow(1 - degradation, year - 1);
    const unitsGenerated = Math.round(annualGeneration * degradationFactor);
    const escalatedRate = unitRate * Math.pow(1 + tariffEscalation, year - 1);
    const valueGenerated = unitsGenerated * escalatedRate;
    return { unitsGenerated, escalatedRate, valueGenerated };
  };

  let cumulativeSavings = -initialInvestment;
  let paybackYear = 0;

  const years = Array.from({ length: 25 }, (_, i) => {
    const year = i + 1;
    const { unitsGenerated, escalatedRate, valueGenerated } = calculateYearData(year);
    
    const previousBalance = cumulativeSavings;
    cumulativeSavings += valueGenerated;
    
    if (paybackYear === 0 && cumulativeSavings >= 0) {
      paybackYear = year;
    }

    return {
      year,
      unitsGenerated,
      unitRate: escalatedRate,
      valueGenerated,
      remainingInvestment: Math.max(0, -previousBalance),
      savings: previousBalance < 0 ? Math.max(0, valueGenerated + previousBalance) : valueGenerated,
      cumulativeSavings,
    };
  });

  const paybackMonths = paybackYear > 0 ? (paybackYear - 1) * 12 + 
    Math.ceil((years[paybackYear - 1].remainingInvestment / years[paybackYear - 1].valueGenerated) * 12) : 0;
  const paybackYearsDisplay = Math.floor(paybackMonths / 12);
  const paybackMonthsDisplay = paybackMonths % 12;

  return (
    <div className="space-y-8">
      {/* Solar-themed Header */}
      <div className="relative overflow-hidden rounded-lg bg-gradient-to-r from-green-600 via-emerald-500 to-teal-500 p-8 text-white">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
        <div className="relative z-10">
          <TrendingUp className="w-12 h-12 mb-3" />
          <h2 className="text-3xl font-semibold mb-2" data-testid="text-roi-title">
            25-Year ROI Analysis & Financial Projections
          </h2>
          <p className="text-green-100">
            Detailed year-by-year breakdown of your solar investment returns
          </p>
        </div>
      </div>

      {/* Payback Period Highlight */}
      <Card className="p-6 bg-primary/5 border-primary/20">
        <div className="flex items-center gap-6">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Payback Period</p>
            <p className="text-3xl font-bold font-mono text-primary" data-testid="text-payback-period">
              {paybackYearsDisplay} years {paybackMonthsDisplay} months
            </p>
          </div>
          <div className="h-12 w-px bg-border" />
          <div>
            <p className="text-sm text-muted-foreground mb-1">Total 25-Year Savings</p>
            <p className="text-3xl font-bold font-mono text-green-600" data-testid="text-total-savings">
              ₹{years[24].cumulativeSavings.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </p>
          </div>
        </div>
      </Card>

      {/* ROI Table */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="font-semibold text-center">Year</TableHead>
                <TableHead className="font-semibold text-right">Units Generated</TableHead>
                <TableHead className="font-semibold text-right">MSEB Rate (₹)</TableHead>
                <TableHead className="font-semibold text-right">Value Generated</TableHead>
                <TableHead className="font-semibold text-right">Investment Remaining</TableHead>
                <TableHead className="font-semibold text-right">Annual Savings</TableHead>
                <TableHead className="font-semibold text-right">Cumulative Savings</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {years.map((yearData) => (
                <TableRow 
                  key={yearData.year}
                  className={yearData.year === paybackYear ? "bg-green-50 dark:bg-green-950/20" : ""}
                  data-testid={`row-year-${yearData.year}`}
                >
                  <TableCell className="text-center font-mono font-semibold">
                    {yearData.year}
                    {yearData.year === paybackYear && (
                      <Badge variant="secondary" className="ml-2 text-xs">Breakeven</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    {yearData.unitsGenerated.toLocaleString('en-IN')}
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    ₹{yearData.unitRate.toFixed(2)}
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    ₹{yearData.valueGenerated.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  </TableCell>
                  <TableCell className="text-right font-mono text-destructive">
                    {yearData.remainingInvestment > 0 
                      ? `₹${yearData.remainingInvestment.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`
                      : '-'
                    }
                  </TableCell>
                  <TableCell className="text-right font-mono text-green-600">
                    {yearData.savings > 0 
                      ? `₹${yearData.savings.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`
                      : '-'
                    }
                  </TableCell>
                  <TableCell className={`text-right font-mono font-semibold ${yearData.cumulativeSavings >= 0 ? 'text-green-600' : 'text-destructive'}`}>
                    ₹{yearData.cumulativeSavings.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Assumptions */}
      <Card className="p-6 bg-muted/50">
        <h3 className="text-sm font-semibold mb-3">Calculation Assumptions:</h3>
        <ul className="text-sm text-muted-foreground space-y-1.5">
          <li>• Daily generation: 4 units per kW (industry standard for India)</li>
          <li>• Annual panel degradation: 0.5% per year</li>
          <li>• Electricity tariff escalation: 2% per year</li>
          <li>• System warranty: 25 years (panels), 5 years (inverter)</li>
          <li>• Zero maintenance cost for on-grid net metering system</li>
        </ul>
      </Card>
    </div>
  );
}
