import ScopeOfWork from '../ScopeOfWork';

export default function ScopeOfWorkExample() {
  return (
    <div className="p-8">
      <ScopeOfWork />
    </div>
  );
}
