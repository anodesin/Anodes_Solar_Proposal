import EnergyCalculator from '../EnergyCalculator';

export default function EnergyCalculatorExample() {
  return (
    <div className="p-8">
      <EnergyCalculator monthlyUnits={7200} proposedSystemKw={55} />
    </div>
  );
}
