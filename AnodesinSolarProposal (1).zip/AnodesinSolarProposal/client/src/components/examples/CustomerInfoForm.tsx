import CustomerInfoForm from '../CustomerInfoForm';

export default function CustomerInfoFormExample() {
  return (
    <div className="p-8">
      <CustomerInfoForm 
        onSubmit={(data) => console.log('Customer info submitted:', data)}
        defaultValues={{
          customerName: "Ganga Legend B3",
          customerContact: "9876543210",
          consumerNumber: "160227857720",
          monthlyUnits: 7200,
          proposedSystemKw: 55,
          projectCostPerKw: 55000,
        }}
      />
    </div>
  );
}
