import InfographicROI from '../InfographicROI';

export default function InfographicROIExample() {
  return (
    <div className="p-8">
      <InfographicROI 
        systemKw={55}
        totalInvestment={3025000}
        unitRate={20.62}
      />
    </div>
  );
}
