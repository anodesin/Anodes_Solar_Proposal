import BillOfMaterials from '../BillOfMaterials';

export default function BillOfMaterialsExample() {
  return (
    <div className="p-8">
      <BillOfMaterials systemKw={55} />
    </div>
  );
}
