import CompanyProfile from '../CompanyProfile';

export default function CompanyProfileExample() {
  return (
    <div className="p-8">
      <CompanyProfile />
    </div>
  );
}
