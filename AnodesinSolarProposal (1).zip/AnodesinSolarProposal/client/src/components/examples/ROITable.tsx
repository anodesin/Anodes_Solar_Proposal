import ROITable from '../ROITable';

export default function ROITableExample() {
  return (
    <div className="p-8">
      <ROITable 
        systemKw={55} 
        initialInvestment={3025000}
        unitRate={20.62}
      />
    </div>
  );
}
