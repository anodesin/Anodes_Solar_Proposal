import TermsAndWarranty from '../TermsAndWarranty';

export default function TermsAndWarrantyExample() {
  return (
    <div className="p-8">
      <TermsAndWarranty />
    </div>
  );
}
