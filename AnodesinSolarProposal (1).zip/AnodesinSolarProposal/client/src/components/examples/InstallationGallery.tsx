import InstallationGallery from '../InstallationGallery';

export default function InstallationGalleryExample() {
  return (
    <div className="p-8">
      <InstallationGallery />
    </div>
  );
}
