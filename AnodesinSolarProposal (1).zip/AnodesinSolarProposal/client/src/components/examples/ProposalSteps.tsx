import ProposalSteps from '../ProposalSteps';

export default function ProposalStepsExample() {
  return <ProposalSteps currentStep={3} totalSteps={6} />;
}
