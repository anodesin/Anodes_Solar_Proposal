import PricingCalculator from '../PricingCalculator';

export default function PricingCalculatorExample() {
  return (
    <div className="p-8">
      <PricingCalculator 
        systemKw={55} 
        costPerKw={55000}
        subsidyAmount={50000}
      />
    </div>
  );
}
