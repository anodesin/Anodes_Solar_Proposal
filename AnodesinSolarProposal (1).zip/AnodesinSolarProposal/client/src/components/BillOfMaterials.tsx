import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";

interface BillOfMaterialsProps {
  systemKw: number;
}

export default function BillOfMaterials({ systemKw }: BillOfMaterialsProps) {
  // Calculate number of panels needed (590W each)
  const panelWattage = 590;
  const numberOfPanels = Math.ceil((systemKw * 1000) / panelWattage);

  const materials = [
    {
      component: "PV Modules",
      type: "Monocrystalline Bifacial DCR",
      specification: `${panelWattage}Wp Solar Panels`,
      quantity: `${numberOfPanels} Nos`,
      make: "Waaree, Navitas, ECE, Vikram",
      warranty: "27 Years (10 years manufacturing defects)",
    },
    {
      component: "On-Grid Inverter",
      type: `${Math.ceil(systemKw)} kW On Grid Inverter`,
      specification: "Efficiency: >98%",
      quantity: "1 No",
      make: "Growatt, Waaree",
      warranty: "5 Years",
    },
    {
      component: "Mounting Structure",
      type: "Fixed Mounting Structure",
      specification: "Galvanized Structure Hot Dipped with Clamp",
      quantity: "1 Set",
      make: "GI",
      warranty: "15 Years",
    },
    {
      component: "DC Distribution Box",
      type: "2 In 2 Out",
      specification: "IP 65 Protected",
      quantity: "1 Set",
      make: "MCB-ABB",
      warranty: "5 Years",
    },
    {
      component: "AC Distribution Box",
      type: "3 Phase ACDB",
      specification: "IP 65 Protected, Indicator RYB & SPD (1Ph)",
      quantity: "1 Set",
      make: "MCB-ABB",
      warranty: "5 Years",
    },
    {
      component: "Earthing Kit",
      type: "Chemo Maintenance Type",
      specification: "Complete Earthing System",
      quantity: "1 No",
      make: "Reputed Make",
      warranty: "5 Years",
    },
    {
      component: "Lightning Arrestor",
      type: "Reputed Make",
      specification: "Protection System",
      quantity: "1 No",
      make: "Reputed Make",
      warranty: "5 Years",
    },
    {
      component: "AC & DC Cables",
      type: "DC Cable / 1000V, AC – 4 Core",
      specification: "As Per Design",
      quantity: "As Per Design",
      make: "Polycab",
      warranty: "5 Years",
    },
    {
      component: "Net Meter",
      type: "3 Phase Bi-Directional",
      specification: "Net Metering Equipment",
      quantity: "1 No",
      make: "HPL / Adani / Standard 3Ph",
      warranty: "1 Year",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Solar-themed Header */}
      <div className="relative overflow-hidden rounded-lg bg-gradient-to-r from-indigo-600 via-purple-500 to-pink-500 p-8 text-white">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
        <div className="relative z-10">
          <Check className="w-12 h-12 mb-3" />
          <h2 className="text-3xl font-semibold mb-2" data-testid="text-bom-title">
            Bill of Materials & Technical Specifications
          </h2>
          <p className="text-purple-100">
            Complete list of premium components for your {systemKw}kW solar power system
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {materials.map((material, index) => (
          <Card key={index} className="p-6" data-testid={`card-material-${index}`}>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Component Details */}
              <div className="lg:col-span-2">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                    <Check className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold mb-1">{material.component}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{material.type}</p>
                    <div className="space-y-1.5">
                      <div className="flex gap-2 text-sm">
                        <span className="text-muted-foreground min-w-24">Specification:</span>
                        <span className="font-medium">{material.specification}</span>
                      </div>
                      <div className="flex gap-2 text-sm">
                        <span className="text-muted-foreground min-w-24">Quantity:</span>
                        <span className="font-medium font-mono">{material.quantity}</span>
                      </div>
                      <div className="flex gap-2 text-sm">
                        <span className="text-muted-foreground min-w-24">Make:</span>
                        <span className="font-medium">{material.make}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Warranty Badge */}
              <div className="flex items-start justify-start lg:justify-end">
                <Badge variant="secondary" className="text-sm px-4 py-2">
                  {material.warranty} Warranty
                </Badge>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card className="p-6 bg-muted/50">
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold">Note:</span> Due to shortage of DCR Panels in the market,
          available brands of solar panels can be installed with prior permission only.
        </p>
      </Card>
    </div>
  );
}
