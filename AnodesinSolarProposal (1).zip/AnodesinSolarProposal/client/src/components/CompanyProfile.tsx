import { Card } from "@/components/ui/card";
import heroImage from "@assets/IMG_20231119_180644_1761342095686.jpg";
import { Award, Users, Target, Shield, TrendingUp, Sun } from "lucide-react";

export default function CompanyProfile() {
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="relative h-96 rounded-lg overflow-hidden">
        <img 
          src={heroImage}
          alt="Solar Installation"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white max-w-3xl px-6">
            <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="text-company-name">
              Anodes Incorporate
            </h1>
            <p className="text-xl md:text-2xl mb-2 text-gray-200">
              Leading Solar Energy Solutions Provider
            </p>
            <p className="text-lg text-gray-300">
              Empowering sustainable futures through innovative solar technology
            </p>
          </div>
        </div>
      </div>

      {/* Mission & Vision */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="p-8">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Target className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-semibold mb-3">Our Mission</h2>
              <p className="text-muted-foreground leading-relaxed">
                To provide sustainable, cost-effective solar energy solutions that empower 
                businesses and homes to achieve energy independence while contributing to a 
                cleaner environment for future generations.
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-8">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Sun className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-semibold mb-3">Our Vision</h2>
              <p className="text-muted-foreground leading-relaxed">
                To be India's most trusted solar energy partner, recognized for delivering 
                innovative, high-quality installations that maximize returns on investment 
                and promote environmental sustainability across all sectors.
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Core Values */}
      <div>
        <h2 className="text-2xl font-semibold mb-6">Core Values</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
              <Shield className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Quality & Reliability</h3>
            <p className="text-sm text-muted-foreground">
              We use only premium components with industry-leading warranties, ensuring 
              long-term performance and peace of mind.
            </p>
          </Card>

          <Card className="p-6">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Customer First</h3>
            <p className="text-sm text-muted-foreground">
              Every project is tailored to customer needs with transparent pricing, 
              detailed proposals, and dedicated post-installation support.
            </p>
          </Card>

          <Card className="p-6">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
              <TrendingUp className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Innovation & Excellence</h3>
            <p className="text-sm text-muted-foreground">
              Continuous adoption of latest solar technologies and best practices to 
              deliver superior efficiency and maximum ROI.
            </p>
          </Card>
        </div>
      </div>

      {/* Experience & Expertise */}
      <Card className="p-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Award className="w-8 h-8 text-primary" />
            </div>
            <p className="text-3xl font-bold font-mono text-primary mb-1">500+</p>
            <p className="text-sm text-muted-foreground">Projects Completed</p>
          </div>
          <div>
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Sun className="w-8 h-8 text-primary" />
            </div>
            <p className="text-3xl font-bold font-mono text-primary mb-1">50+ MW</p>
            <p className="text-sm text-muted-foreground">Total Installed Capacity</p>
          </div>
          <div>
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Users className="w-8 h-8 text-primary" />
            </div>
            <p className="text-3xl font-bold font-mono text-primary mb-1">98%</p>
            <p className="text-sm text-muted-foreground">Customer Satisfaction</p>
          </div>
          <div>
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Shield className="w-8 h-8 text-primary" />
            </div>
            <p className="text-3xl font-bold font-mono text-primary mb-1">25 Years</p>
            <p className="text-sm text-muted-foreground">Warranty Protection</p>
          </div>
        </div>
      </Card>

      {/* Certifications */}
      <div>
        <h2 className="text-2xl font-semibold mb-6">Certifications & Accreditations</h2>
        <Card className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
              <div>
                <h3 className="font-semibold mb-1">ISO 9001:2015 Certified</h3>
                <p className="text-sm text-muted-foreground">
                  Quality Management System certification ensuring consistent service delivery
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
              <div>
                <h3 className="font-semibold mb-1">MNRE Empaneled</h3>
                <p className="text-sm text-muted-foreground">
                  Ministry of New and Renewable Energy approved installer
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
              <div>
                <h3 className="font-semibold mb-1">Authorized Channel Partner</h3>
                <p className="text-sm text-muted-foreground">
                  Certified partner for leading solar panel and inverter manufacturers
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
              <div>
                <h3 className="font-semibold mb-1">Electrical Contractor License</h3>
                <p className="text-sm text-muted-foreground">
                  Licensed for commercial and residential electrical installations
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
