import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface Step {
  id: number;
  title: string;
  completed: boolean;
  active: boolean;
}

interface ProposalStepsProps {
  currentStep: number;
  totalSteps: number;
}

export default function ProposalSteps({ currentStep, totalSteps }: ProposalStepsProps) {
  const stepTitles = [
    "Customer Info",
    "Energy Assessment",
    "Technical Specs",
    "Pricing",
    "ROI Analysis",
    "Review"
  ];

  const steps: Step[] = stepTitles.slice(0, totalSteps).map((title, index) => ({
    id: index + 1,
    title,
    completed: index + 1 < currentStep,
    active: index + 1 === currentStep,
  }));

  return (
    <div className="w-full py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center flex-1">
              {/* Step Circle */}
              <div className="flex flex-col items-center gap-2">
                <div
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold transition-colors",
                    step.completed && "bg-green-500 text-white",
                    step.active && "bg-primary text-primary-foreground ring-2 ring-primary ring-offset-2",
                    !step.completed && !step.active && "bg-muted text-muted-foreground"
                  )}
                  data-testid={`step-indicator-${step.id}`}
                >
                  {step.completed ? <Check className="w-5 h-5" /> : step.id}
                </div>
                <span className={cn(
                  "text-xs font-medium hidden sm:block text-center",
                  step.active && "text-foreground",
                  !step.active && "text-muted-foreground"
                )}
                data-testid={`step-title-${step.id}`}>
                  {step.title}
                </span>
              </div>

              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className={cn(
                  "flex-1 h-0.5 mx-2 transition-colors",
                  step.completed ? "bg-green-500" : "bg-muted"
                )}
                />
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
