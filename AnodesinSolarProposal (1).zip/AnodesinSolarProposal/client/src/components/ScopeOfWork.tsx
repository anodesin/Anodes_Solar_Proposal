import { Card } from "@/components/ui/card";
import { CheckCircle2, Clock } from "lucide-react";

export default function ScopeOfWork() {
  const phases = [
    {
      phase: "Phase 1: Site Assessment & Planning",
      duration: "Week 1",
      activities: [
        "Detailed site survey and structural assessment",
        "Shadow analysis and optimal panel placement planning",
        "Electrical load analysis and system design",
        "Obtaining necessary approvals and permits",
      ],
    },
    {
      phase: "Phase 2: Procurement & Mobilization",
      duration: "Week 2-3",
      activities: [
        "Procurement of solar panels, inverters, and BOS components",
        "Quality inspection of all materials",
        "Mobilization of installation team and equipment",
        "Site preparation and safety arrangements",
      ],
    },
    {
      phase: "Phase 3: Installation",
      duration: "Week 4-6",
      activities: [
        "Installation of mounting structures",
        "Panel installation and wiring",
        "Inverter and electrical equipment installation",
        "ACDB, DCDB, and earthing system setup",
      ],
    },
    {
      phase: "Phase 4: Testing & Commissioning",
      duration: "Week 7-8",
      activities: [
        "System testing and performance verification",
        "Net meter installation coordination with MSEB",
        "Safety checks and quality assurance",
        "System handover and customer training",
      ],
    },
  ];

  const deliverables = [
    "Complete on-grid solar PV system as per specifications",
    "All electrical components and safety equipment installed",
    "Net metering setup completed with utility approval",
    "Comprehensive system documentation and warranties",
    "Customer training on system operation and monitoring",
    "After-sales support and maintenance guidance",
  ];

  return (
    <div className="space-y-8">
      {/* Solar-themed Header */}
      <div className="relative overflow-hidden rounded-lg bg-gradient-to-r from-cyan-600 via-blue-500 to-indigo-500 p-8 text-white">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
        <div className="relative z-10">
          <CheckCircle2 className="w-12 h-12 mb-3" />
          <h2 className="text-3xl font-semibold mb-2" data-testid="text-scope-title">
            Scope of Work
          </h2>
          <p className="text-cyan-100">
            Detailed project execution plan with timeline and deliverables
          </p>
        </div>
      </div>

      {/* Timeline Badge */}
      <Card className="p-6 bg-primary/5 border-primary/20">
        <div className="flex items-center gap-3">
          <Clock className="w-8 h-8 text-primary" />
          <div>
            <p className="text-sm text-muted-foreground">Total Project Duration</p>
            <p className="text-2xl font-bold text-primary" data-testid="text-project-duration">
              2 Months
            </p>
          </div>
        </div>
      </Card>

      {/* Project Phases */}
      <div className="space-y-6">
        <h3 className="text-lg font-semibold">Project Execution Phases</h3>
        {phases.map((phase, index) => (
          <Card key={index} className="p-6" data-testid={`card-phase-${index + 1}`}>
            <div className="flex items-start gap-4 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold flex-shrink-0">
                {index + 1}
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between mb-3 gap-4">
                  <h4 className="text-lg font-semibold">{phase.phase}</h4>
                  <span className="text-sm font-medium text-primary bg-primary/10 px-3 py-1 rounded-full whitespace-nowrap">
                    {phase.duration}
                  </span>
                </div>
                <ul className="space-y-2">
                  {phase.activities.map((activity, actIndex) => (
                    <li key={actIndex} className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{activity}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Deliverables */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Project Deliverables</h3>
        <Card className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {deliverables.map((deliverable, index) => (
              <div key={index} className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-sm text-muted-foreground">{deliverable}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Responsibilities */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Our Responsibilities</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              <span>Complete system design and engineering</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              <span>Procurement of all materials and components</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              <span>Professional installation and commissioning</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              <span>Coordination with electricity board for net metering</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              <span>Warranty registration and documentation</span>
            </li>
          </ul>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Customer Responsibilities</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              <span>Provide site access during working hours</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              <span>Ensure structural integrity of installation area</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              <span>Timely approval of designs and documentation</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              <span>Payment as per agreed schedule</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              <span>Basic maintenance and cleaning of panels</span>
            </li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
