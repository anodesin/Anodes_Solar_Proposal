import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Header from "@/components/Header";
import ProposalSteps from "@/components/ProposalSteps";
import CustomerInfoForm, { type CustomerInfo } from "@/components/CustomerInfoForm";
import EnergyCalculator from "@/components/EnergyCalculator";
import BillOfMaterials from "@/components/BillOfMaterials";
import PricingCalculator from "@/components/PricingCalculator";
import ROITable from "@/components/ROITable";
import InfographicROI from "@/components/InfographicROI";
import CompanyProfile from "@/components/CompanyProfile";
import ScopeOfWork from "@/components/ScopeOfWork";
import TermsAndWarranty from "@/components/TermsAndWarranty";
import InstallationGallery from "@/components/InstallationGallery";
import { ChevronLeft, ChevronRight, Download, FileText } from "lucide-react";

export default function Home() {
  const [currentPage, setCurrentPage] = useState(0);
  const [customerData, setCustomerData] = useState<CustomerInfo | null>(null);

  const handleCustomerInfoSubmit = (data: CustomerInfo) => {
    console.log('Customer data submitted:', data);
    setCustomerData(data);
    setCurrentPage(1);
  };

  const pages = [
    {
      title: "Customer Information",
      component: <CustomerInfoForm onSubmit={handleCustomerInfoSubmit} defaultValues={customerData || undefined} />
    },
    {
      title: "Company Profile",
      component: <CompanyProfile />
    },
    {
      title: "Energy Assessment",
      component: customerData ? (
        <EnergyCalculator 
          monthlyUnits={customerData.monthlyUnits}
          proposedSystemKw={customerData.proposedSystemKw}
        />
      ) : <div>Please complete customer information first</div>
    },
    {
      title: "Technical Specifications",
      component: customerData ? (
        <BillOfMaterials systemKw={customerData.proposedSystemKw} />
      ) : <div>Please complete customer information first</div>
    },
    {
      title: "Pricing Structure",
      component: customerData ? (
        <PricingCalculator 
          systemKw={customerData.proposedSystemKw}
          costPerKw={customerData.projectCostPerKw}
          subsidyAmount={customerData.subsidyAmount}
        />
      ) : <div>Please complete customer information first</div>
    },
    {
      title: "Investment Infographic",
      component: customerData ? (
        <InfographicROI 
          systemKw={customerData.proposedSystemKw}
          totalInvestment={customerData.proposedSystemKw * customerData.projectCostPerKw * 1.089}
          unitRate={customerData.currentBillAmount / customerData.monthlyUnits}
        />
      ) : <div>Please complete customer information first</div>
    },
    {
      title: "ROI Analysis",
      component: customerData ? (
        <ROITable 
          systemKw={customerData.proposedSystemKw}
          initialInvestment={customerData.proposedSystemKw * customerData.projectCostPerKw * 1.089}
          unitRate={customerData.currentBillAmount / customerData.monthlyUnits}
        />
      ) : <div>Please complete customer information first</div>
    },
    {
      title: "Scope of Work",
      component: <ScopeOfWork />
    },
    {
      title: "Terms & Warranty",
      component: <TermsAndWarranty />
    },
    {
      title: "Installation Gallery",
      component: <InstallationGallery />
    },
  ];

  const canNavigateNext = currentPage === 0 ? customerData !== null : currentPage < pages.length - 1;

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-primary/5 to-background">
      <Header />
      
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Progress Steps */}
        {customerData && currentPage > 0 && (
          <ProposalSteps 
            currentStep={currentPage} 
            totalSteps={pages.length}
          />
        )}

        {/* Page Content */}
        <Card className="p-8 mb-8">
          {pages[currentPage].component}
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between gap-4">
          <Button
            variant="outline"
            onClick={() => setCurrentPage(prev => prev - 1)}
            disabled={currentPage === 0}
            data-testid="button-previous"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>

          <div className="flex items-center gap-3">
            {customerData && (
              <Button
                variant="outline"
                onClick={() => console.log('Generate PDF clicked')}
                data-testid="button-generate-pdf"
              >
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
            )}
            <span className="text-sm text-muted-foreground">
              Page {currentPage + 1} of {pages.length}
            </span>
          </div>

          <Button
            onClick={() => setCurrentPage(prev => prev + 1)}
            disabled={!canNavigateNext}
            data-testid="button-next"
          >
            Next
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>

        {/* Quick Navigation - Page List */}
        {customerData && (
          <Card className="mt-8 p-6">
            <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Quick Navigation
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
              {pages.map((page, index) => (
                <Button
                  key={index}
                  variant={currentPage === index ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(index)}
                  className="justify-start"
                  data-testid={`button-nav-${index}`}
                >
                  {index + 1}. {page.title}
                </Button>
              ))}
            </div>
          </Card>
        )}
      </main>
    </div>
  );
}
