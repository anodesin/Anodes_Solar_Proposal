import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const proposals = pgTable("proposals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerName: text("customer_name").notNull(),
  customerAddress: text("customer_address").notNull(),
  customerContact: text("customer_contact").notNull(),
  consumerNumber: text("consumer_number").notNull(),
  monthlyUnits: integer("monthly_units").notNull(),
  currentBillAmount: numeric("current_bill_amount", { precision: 10, scale: 2 }).notNull(),
  demandCharges: numeric("demand_charges", { precision: 10, scale: 2 }).notNull(),
  sanctionLoad: numeric("sanction_load", { precision: 10, scale: 2 }).notNull(),
  proposedSystemKw: numeric("proposed_system_kw", { precision: 10, scale: 2 }).notNull(),
  rooftopArea: numeric("rooftop_area", { precision: 10, scale: 2 }).notNull(),
  projectCostPerKw: numeric("project_cost_per_kw", { precision: 10, scale: 2 }).notNull(),
  ppaRate: numeric("ppa_rate", { precision: 10, scale: 2 }),
  subsidyAmount: numeric("subsidy_amount", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertProposalSchema = createInsertSchema(proposals).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertProposal = z.infer<typeof insertProposalSchema>;
export type Proposal = typeof proposals.$inferSelect;
